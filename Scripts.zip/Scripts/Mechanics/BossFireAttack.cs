using Platformer.Core;
using Platformer.Model;
using Platformer.View;
using UnityEngine;

namespace Platformer.Mechanics
{
    public class BossFireAttack : MonoBehaviour
    {
        [SerializeField] private BossController boss;
        [SerializeField] private float fireInterval = 4.5f;
        [SerializeField] private float attackRange = 14f;
        [SerializeField] private int damage = 1;
        [SerializeField] private float projectileSpeed = 8f;
        [SerializeField] private float projectileRange = 16f;
        [SerializeField] private float hitRadius = 0.55f;
        [SerializeField] private Sprite fireSprite;
        [SerializeField] private GameObject impactVfx;
        [SerializeField] private Color fireColor = new Color(1f, 0.92f, 0.2f, 1f);
        [SerializeField] private GameElement element = GameElement.Rayo;

        PlatformerModel model;
        SpriteRenderer spriteRenderer;
        Animator animator;
        float nextFireTime;

        public GameElement Element => element;

        void Awake()
        {
            model = Simulation.GetModel<PlatformerModel>();
            spriteRenderer = GetComponent<SpriteRenderer>();
            animator = GetComponent<Animator>();
            if (boss == null) boss = GetComponent<BossController>();
        }

        void Update()
        {
            if (boss == null || !boss.CombatStarted || model == null || model.player == null) return;
            if (model.player.Health == null || !model.player.Health.IsAlive) return;

            Vector2 origin = transform.position;
            Vector2 target = model.player.transform.position;
            float distance = Vector2.Distance(origin, target);
            if (distance > attackRange) return;

            if (nextFireTime <= 0f) nextFireTime = Time.time + fireInterval * 0.5f;
            if (Time.time < nextFireTime) return;

            Fire((target - origin).normalized);
            nextFireTime = Time.time + fireInterval;
        }

        void Fire(Vector2 direction)
        {
            Vector2 muzzle = (Vector2)transform.position + direction * 0.9f;
            Color attackColor = element == GameElement.Rayo ? new Color(1f, 0.92f, 0.2f, 1f) : fireColor;
            BossFireball.Spawn(muzzle, direction, projectileSpeed, projectileRange, hitRadius,
                damage, fireSprite, attackColor, impactVfx);

            if (spriteRenderer != null) spriteRenderer.flipX = direction.x < 0f;
            if (animator != null)
            {
                foreach (AnimatorControllerParameter parameter in animator.parameters)
                {
                    if (parameter.name == "attack" && parameter.type == AnimatorControllerParameterType.Trigger)
                    {
                        animator.SetTrigger("attack");
                        break;
                    }
                }
            }
            CircleEffect.Spawn(muzzle, 0.55f, attackColor);
        }
    }
}
