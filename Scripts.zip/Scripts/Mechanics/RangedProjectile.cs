using System.Collections.Generic;
using Platformer.Mechanics;
using Platformer.View;
using UnityEngine;

namespace Platformer.Mechanics
{
    public class RangedProjectile : MonoBehaviour
    {
        Vector2 direction;
        float speed;
        float range;
        float hitRadius;
        float travelled;
        int damage;
        GameObject impactVfx;
        Color color;
        Component[] targets;
        readonly HashSet<Health> hitEnemies = new HashSet<Health>();

        static Sprite boltSprite;

        public static RangedProjectile Spawn(Vector2 origin, Vector2 direction, float speed, float range,
            float hitRadius, int damage, GameObject impactVfx, Color color)
        {
            var go = new GameObject("Ranged Bolt");
            go.transform.position = origin;
            var projectile = go.AddComponent<RangedProjectile>();
            projectile.direction = direction.normalized;
            projectile.speed = speed;
            projectile.range = range;
            projectile.hitRadius = hitRadius;
            projectile.damage = damage;
            projectile.impactVfx = impactVfx;
            projectile.color = color;
            var targetList = new List<Component>();
            targetList.AddRange(UnityEngine.Object.FindObjectsByType<EnemyController>(FindObjectsInactive.Exclude));
            targetList.AddRange(UnityEngine.Object.FindObjectsByType<BossController>(FindObjectsInactive.Exclude));
            projectile.targets = targetList.ToArray();
            projectile.transform.right = projectile.direction;

            var renderer = go.AddComponent<SpriteRenderer>();
            renderer.sprite = GetBoltSprite();
            renderer.color = color;
            renderer.sortingOrder = 40;
            go.transform.localScale = new Vector3(0.45f, 0.45f, 1f);
            return projectile;
        }

        void Update()
        {
            Vector2 previous = transform.position;
            float step = speed * Time.deltaTime;
            transform.position += (Vector3)(direction * step);
            travelled += step;
            transform.right = direction;

            float hitDistance = hitRadius + 0.45f;
            foreach (Component target in targets)
            {
                if (target == null) continue;
                Vector2 targetPosition = (Vector2)target.transform.position + new Vector2(0f, 0.35f);
                if (SquaredDistanceToSegment(targetPosition, previous, transform.position) > hitDistance * hitDistance) continue;

                Health health = target.GetComponent<Health>();
                if (health == null || !health.IsAlive || hitEnemies.Contains(health)) continue;

                hitEnemies.Add(health);
                for (int i = 0; i < damage && health.IsAlive; i++)
                    health.Decrement();

                Animator enemyAnimator = target.GetComponent<Animator>();
                if (enemyAnimator != null) enemyAnimator.SetTrigger("hurt");
                Impact();
                return;
            }

            if (travelled >= range) Impact();
        }

        static float SquaredDistanceToSegment(Vector2 point, Vector2 start, Vector2 end)
        {
            Vector2 segment = end - start;
            float lengthSquared = segment.sqrMagnitude;
            if (lengthSquared < 0.000001f) return (point - start).sqrMagnitude;

            float t = Mathf.Clamp01(Vector2.Dot(point - start, segment) / lengthSquared);
            return (point - (start + segment * t)).sqrMagnitude;
        }

        void Impact()
        {
            if (impactVfx != null)
                Instantiate(impactVfx, transform.position, Quaternion.identity);
            else
                CircleEffect.Spawn(transform.position, 0.5f, color);
            Destroy(gameObject);
        }

        static Sprite GetBoltSprite()
        {
            if (boltSprite != null) return boltSprite;
            var texture = new Texture2D(16, 8, TextureFormat.RGBA32, false);
            var pixels = new Color[16 * 8];
            for (int y = 0; y < 8; y++)
            {
                for (int x = 0; x < 16; x++)
                {
                    float edge = 1f - Mathf.Abs(y - 3.5f) / 4f;
                    float tip = 1f - Mathf.Abs(x - 7.5f) / 8f;
                    pixels[y * 16 + x] = new Color(1f, 1f, 1f, edge * tip);
                }
            }
            texture.SetPixels(pixels);
            texture.Apply();
            texture.filterMode = FilterMode.Bilinear;
            boltSprite = Sprite.Create(texture, new Rect(0, 0, 16, 8), new Vector2(0.5f, 0.5f), 16f);
            return boltSprite;
        }
    }
}
