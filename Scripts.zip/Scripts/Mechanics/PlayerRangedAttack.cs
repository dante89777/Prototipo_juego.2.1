using UnityEngine;
using UnityEngine.InputSystem;

namespace Platformer.Mechanics
{
    [RequireComponent(typeof(PlayerController))]
    public class PlayerRangedAttack : MonoBehaviour
    {
        [Header("Proyectil")]
        [SerializeField] private float projectileSpeed = 16f;
        [SerializeField] private float range = 10f;
        [SerializeField] private float hitRadius = 0.28f;
        [SerializeField] private int damage = 1;
        [SerializeField] private float attackCooldown = 0.3f;

        [Header("Efectos")]
        [SerializeField] private GameObject impactVfx;
        [SerializeField] private AudioClip attackAudio;
        [SerializeField] private Color projectileColor = new Color(0.35f, 1f, 1f, 1f);

        PlayerController player;
        SpriteRenderer spriteRenderer;
        InputAction attackAction;
        float nextAttackTime;

        void Awake()
        {
            player = GetComponent<PlayerController>();
            spriteRenderer = GetComponent<SpriteRenderer>();
        }

        void OnEnable()
        {
            attackAction = InputSystem.actions.FindAction("Player/Attack");
            if (attackAction != null) attackAction.Enable();
        }

        void Update()
        {
            if (player == null || !player.ControlEnabled || Time.timeScale <= 0f) return;
            if (AttackPressed()) Fire();
        }

        bool AttackPressed()
        {
            if (attackAction != null) return attackAction.WasPressedThisFrame();
            return Mouse.current != null && Mouse.current.leftButton.wasPressedThisFrame;
        }

        public void Fire()
        {
            if (Time.time < nextAttackTime) return;
            nextAttackTime = Time.time + attackCooldown;

            Vector2 origin = (Vector2)transform.position + new Vector2(0f, 0.45f);
            Vector2 direction = GetAimDirection(origin);
            if (spriteRenderer != null && Mathf.Abs(direction.x) > 0.01f)
                spriteRenderer.flipX = direction.x < 0f;

            RangedProjectile.Spawn(origin, direction, projectileSpeed, range, hitRadius, damage,
                impactVfx, projectileColor);

            if (attackAudio != null && player != null && player.AudioSource != null)
                player.AudioSource.PlayOneShot(attackAudio);
        }

        Vector2 GetAimDirection(Vector2 origin)
        {
            if (Mouse.current != null && Camera.main != null)
            {
                Vector3 world = Camera.main.ScreenToWorldPoint(Mouse.current.position.ReadValue());
                Vector2 direction = (Vector2)(world - (Vector3)origin);
                if (direction.sqrMagnitude > 0.0001f) return direction.normalized;
            }
            return spriteRenderer != null && spriteRenderer.flipX ? Vector2.left : Vector2.right;
        }
    }
}
