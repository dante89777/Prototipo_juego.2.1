using System.Collections.Generic;
using Platformer.Core;
using Platformer.Model;
using UnityEngine;
using UnityEngine.InputSystem;

namespace Platformer.Mechanics
{
    [RequireComponent(typeof(PlayerController))]
    public class ElementalAttack : MonoBehaviour
    {
        [SerializeField] private Key elementalKey = Key.E;
        [SerializeField] private Key definitiveKey = Key.Q;
        [SerializeField] private float elementalRadius = 2.4f;
        [SerializeField] private int elementalDamage = 2;
        [SerializeField] private float elementalCooldown = 1.1f;
        [SerializeField] private float definitiveRadius = 4.5f;
        [SerializeField] private int definitiveDamage = 99;
        [SerializeField] private float definitiveCooldown = 8f;
        [SerializeField] private GameObject fireVfx;
        [SerializeField] private GameObject lightningVfx;
        [SerializeField] private GameObject iceVfx;
        [SerializeField] private GameObject earthVfx;
        [SerializeField] private GameObject plantVfx;
        [SerializeField] private GameObject windVfx;
        [SerializeField] private GameObject waterVfx;
        [SerializeField] private GameObject defaultVfx;
        [SerializeField] private GameObject definitiveVfx;
        [SerializeField] private CharacterSwitcher characterSwitcher;

        private PlatformerModel model;
        private SpriteRenderer sprite;
        private float nextElementalTime;
        private float nextDefinitiveTime;

        void Awake()
        {
            model = Simulation.GetModel<PlatformerModel>();
            sprite = GetComponent<SpriteRenderer>();
        }

        void Update()
        {
            Keyboard keyboard = Keyboard.current;
            if (keyboard == null || Time.timeScale <= 0f) return;
            if (model.player != null && !model.player.ControlEnabled) return;

            if (keyboard[elementalKey].wasPressedThisFrame && Time.time >= nextElementalTime)
                DoElemental();

            if (keyboard[definitiveKey].wasPressedThisFrame && Time.time >= nextDefinitiveTime)
                DoDefinitive();
        }

        void DoElemental()
        {
            nextElementalTime = Time.time + elementalCooldown;
            GameElement element = AttackElement(0);
            Vector3 center = transform.position + Facing() * 0.6f;
            GameObject vfx = VfxFor(element) ?? defaultVfx;

            SpawnVfx(vfx, center, 1f);
            int hits = DamageInRadius(center, elementalRadius, elementalDamage, vfx);

            if (model != null)
                model.ShowMessage(hits > 0
                    ? "DAÑO ELEMENTAL " + NameOf(element) + " - " + hits + " enemigo(s)"
                    : "DAÑO ELEMENTAL " + NameOf(element), 2f);
        }

        void DoDefinitive()
        {
            nextDefinitiveTime = Time.time + definitiveCooldown;
            GameElement element = AttackElement(1);
            Vector3 center = transform.position + Facing() * 0.8f;
            GameObject vfx = VfxFor(element) ?? definitiveVfx ?? defaultVfx;

            SpawnVfx(vfx, center, 1.6f);
            int hits = DamageInRadius(center, definitiveRadius, definitiveDamage, vfx);

            if (model != null)
                model.ShowMessage(hits > 0
                    ? "DAÑO DEFINITIVO " + NameOf(element) + " - " + hits + " enemigo(s)"
                    : "DAÑO DEFINITIVO " + NameOf(element), 2.5f);
        }

        GameElement AttackElement(int index)
        {
            if (characterSwitcher != null)
            {
                CharacterSlot slot = characterSwitcher.GetSlot(characterSwitcher.CurrentIndex);
                if (slot != null)
                    return index == 0 ? slot.elementA : slot.elementB;
            }

            GameElement[] elements = model != null ? model.CurrentElements : null;
            if (elements != null && elements.Length > index)
                return elements[index];

            return GameElement.Ninguno;
        }

        int DamageInRadius(Vector3 center, float radius, int damage, GameObject vfx)
        {
            HashSet<Health> processed = new HashSet<Health>();
            int hits = 0;

            foreach (Collider2D collider in Physics2D.OverlapCircleAll(center, radius))
            {
                EnemyController enemy = collider.GetComponentInParent<EnemyController>();
                BossController boss = collider.GetComponentInParent<BossController>();
                Health health = collider.GetComponentInParent<Health>();
                if ((enemy == null && boss == null) || health == null || !health.IsAlive) continue;
                if (!processed.Add(health)) continue;

                for (int i = 0; i < damage && health.IsAlive; i++)
                    health.Decrement();

                SpawnVfx(vfx, collider.transform.position + Vector3.up * 0.35f, 0.75f);
                hits++;
            }

            return hits;
        }

        void SpawnVfx(GameObject prefab, Vector3 position, float scale)
        {
            if (prefab == null) return;

            GameObject instance = Instantiate(prefab, position, Quaternion.identity);
            instance.transform.localScale *= scale;

            foreach (ParticleSystemRenderer renderer in instance.GetComponentsInChildren<ParticleSystemRenderer>())
                renderer.sortingOrder = 50;
            foreach (SpriteRenderer renderer in instance.GetComponentsInChildren<SpriteRenderer>())
                renderer.sortingOrder = 50;

            Destroy(instance, 4f);
        }

        Vector3 Facing()
        {
            return sprite != null && sprite.flipX ? Vector3.left : Vector3.right;
        }

        GameObject VfxFor(GameElement element)
        {
            switch (element)
            {
                case GameElement.Fuego: return fireVfx;
                case GameElement.Rayo: return lightningVfx;
                case GameElement.Hielo: return iceVfx;
                case GameElement.Tierra: return earthVfx;
                case GameElement.Planta: return plantVfx;
                case GameElement.Viento: return windVfx;
                case GameElement.Agua: return waterVfx;
                default: return defaultVfx;
            }
        }

        string NameOf(GameElement element)
        {
            switch (element)
            {
                case GameElement.Fuego: return "FUEGO";
                case GameElement.Rayo: return "RAYO";
                case GameElement.Hielo: return "HIELO";
                case GameElement.Tierra: return "TIERRA";
                case GameElement.Planta: return "PLANTA";
                case GameElement.Viento: return "VIENTO";
                case GameElement.Agua: return "AGUA";
                default: return "NINGUNO";
            }
        }
    }
}
