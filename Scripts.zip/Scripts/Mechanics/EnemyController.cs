﻿using System.Collections;
using System.Collections.Generic;
using Platformer.Core;
using Platformer.Gameplay;
using Platformer.Model;
using UnityEngine;
using static Platformer.Core.Simulation;

namespace Platformer.Mechanics
{
    /// <summary>
    /// A simple controller for enemies. Provides movement control over a patrol path.
    /// </summary>
    [RequireComponent(typeof(AnimationController), typeof(Collider2D))]
    public class EnemyController : MonoBehaviour
    {
        [Tooltip("Route the enemy follows. If empty the enemy stays still.")]
        [SerializeField] private PatrolPath path;

        [Tooltip("Audio played when the enemy dies.")]
        [SerializeField] private AudioClip ouch;

        [SerializeField] private float chaseRadius = 9f;
        [SerializeField] private float stopDistance = 1f;
        [SerializeField] private float chaseSpeedMultiplier = 1f;

        internal PatrolPath.Mover mover;
        internal AnimationController control;
        internal Collider2D _collider;
        internal AudioSource _audio;
        SpriteRenderer spriteRenderer;
        PlatformerModel model;

        /// <summary>
        /// Route the enemy follows.
        /// </summary>
        public PatrolPath Path
        {
            get { return path; }
            set { path = value; }
        }

        /// <summary>
        /// Audio played when the enemy dies.
        /// </summary>
        public AudioClip Ouch => ouch;

        public Bounds Bounds => _collider.bounds;

        void Awake()
        {
            control = GetComponent<AnimationController>();
            _collider = GetComponent<Collider2D>();
            _audio = GetComponent<AudioSource>();
            spriteRenderer = GetComponent<SpriteRenderer>();
            model = Simulation.GetModel<PlatformerModel>();
            NormalizeAttachedPatrolPath();
        }

        void NormalizeAttachedPatrolPath()
        {
            if (path == null || path.gameObject != gameObject) return;
            if (Mathf.Abs(path.startPosition.y) < 0.5f && Mathf.Abs(path.endPosition.y) < 0.5f &&
                Mathf.Abs(path.startPosition.x) < 4f && Mathf.Abs(path.endPosition.x) < 4f) return;

            Vector2 center = transform.position;
            Vector2 start = path.startPosition - center;
            Vector2 end = path.endPosition - center;

            if ((end - start).magnitude < 0.5f || Mathf.Abs(start.y) > 1f || Mathf.Abs(end.y) > 1f ||
                Mathf.Abs(start.x) > 4f || Mathf.Abs(end.x) > 4f)
            {
                start = new Vector2(-1.2f, 0f);
                end = new Vector2(1.2f, 0f);
            }

            path.startPosition = start;
            path.endPosition = end;
        }

        void OnCollisionEnter2D(Collision2D collision)
        {
            var player = collision.gameObject.GetComponent<PlayerController>();
            if (player != null)
            {
                var ev = Schedule<PlayerEnemyCollision>();
                ev.player = player;
                ev.enemy = this;
            }
        }

        void Update()
        {
            if (TryChase(out float dx)) return;

            control.move.x = 0f;
            if (path == null) return;
            if (mover == null) mover = path.CreateMover(control.MaxSpeed * 0.5f);
            control.move.x = Mathf.Clamp(mover.Position.x - transform.position.x, -1, 1);
        }

        bool TryChase(out float dx)
        {
            dx = 0f;
            if (GetComponent<BossController>() != null) return false;
            if (model == null || model.player == null || control == null) return false;
            if (model.player.Health == null || !model.player.Health.IsAlive) return false;

            Vector2 delta = model.player.transform.position - transform.position;
            if (delta.magnitude > chaseRadius || delta.magnitude <= stopDistance) return false;

            dx = delta.x;
            control.move.x = Mathf.Clamp(dx, -1f, 1f) * chaseSpeedMultiplier;
            if (spriteRenderer != null && Mathf.Abs(dx) > 0.05f) spriteRenderer.flipX = dx < 0f;
            return true;
        }

    }
}
