using Platformer.Core;
using Platformer.Model;
using UnityEngine;
using UnityEngine.InputSystem;

namespace Platformer.Mechanics
{
    [System.Serializable]
    public class CharacterSlot
    {
        public string displayName;
        public Sprite portrait;
        public Sprite sprite;
        public RuntimeAnimatorController animatorController;
        public GameElement elementA;
        public GameElement elementB;
        public bool ranged;
    }

    [RequireComponent(typeof(SpriteRenderer), typeof(Animator))]
    public class CharacterSwitcher : MonoBehaviour
    {
        [SerializeField] private CharacterSlot[] characters;
        [SerializeField] private Key firstCharacterKey = Key.Digit1;
        [SerializeField] private Key secondCharacterKey = Key.Digit2;
        [SerializeField] private PlayerMeleeAttack meleeAttack;
        [SerializeField] private PlayerRangedAttack rangedAttack;
        [SerializeField] private SpriteRenderer spriteRenderer;
        [SerializeField] private SpriteRenderer cyberRenderer;
        [SerializeField] private Animator animator;

        readonly PlatformerModel model = Simulation.GetModel<PlatformerModel>();

        public int CurrentIndex { get; private set; }

        public string CurrentName => characters != null && characters.Length > CurrentIndex
            ? characters[CurrentIndex].displayName
            : string.Empty;

        void Awake()
        {
            if (spriteRenderer == null) spriteRenderer = GetComponent<SpriteRenderer>();
            if (animator == null) animator = GetComponent<Animator>();
            if (meleeAttack == null) meleeAttack = GetComponent<PlayerMeleeAttack>();
            if (rangedAttack == null) rangedAttack = GetComponent<PlayerRangedAttack>();
            Apply(0, false);
        }

        void Update()
        {
            if (Keyboard.current == null || Time.timeScale <= 0f) return;
            if (model.player != null && !model.player.ControlEnabled) return;

            if (Keyboard.current[firstCharacterKey].wasPressedThisFrame)
                SelectCharacter(0);
            else if (Keyboard.current[secondCharacterKey].wasPressedThisFrame)
                SelectCharacter(1);
        }

        public void SelectCharacter(int index)
        {
            if (characters == null || index < 0 || index >= characters.Length) return;
            if (index == CurrentIndex) return;
            Apply(index, true);
        }

        void Apply(int index, bool showMessage)
        {
            if (characters == null || index < 0 || index >= characters.Length) return;

            CurrentIndex = index;
            CharacterSlot slot = characters[index];
            model.SetCharacter(index);

            if (animator != null)
            {
                animator.enabled = false;
                animator.runtimeAnimatorController = slot.animatorController;
                animator.enabled = slot.animatorController != null;
            }

            bool useCyberRenderer = slot.ranged && cyberRenderer != null;
            if (spriteRenderer != null)
            {
                spriteRenderer.enabled = !useCyberRenderer;
                spriteRenderer.sprite = slot.sprite;
            }

            if (cyberRenderer != null)
            {
                cyberRenderer.enabled = useCyberRenderer;
                cyberRenderer.sprite = slot.sprite;
            }

            if (meleeAttack != null) meleeAttack.enabled = !slot.ranged;
            if (rangedAttack != null) rangedAttack.enabled = slot.ranged;

            if (showMessage)
            {
                string elements = $"{NameOf(slot.elementA)} / {NameOf(slot.elementB)}";
                string attack = slot.ranged ? "A DISTANCIA" : "CUERPO A CUERPO";
                model.ShowMessage($"{slot.displayName} - {elements} - {attack}", 2.5f);
            }
        }

        public CharacterSlot GetSlot(int index)
        {
            if (characters == null || index < 0 || index >= characters.Length) return null;
            return characters[index];
        }

        public void EquipElement(int index, GameElement element)
        {
            EquipElement(index, 1, element);
        }

        public void EquipElement(int index, int slotIndex, GameElement element)
        {
            CharacterSlot slot = GetSlot(index);
            if (slot == null || element == GameElement.Ninguno) return;
            if (slotIndex == 0) slot.elementA = element;
            else slot.elementB = element;
        }

        static string NameOf(GameElement value)
        {
            switch (value)
            {
                case GameElement.Fuego: return "FUEGO";
                case GameElement.Rayo: return "RAYO";
                case GameElement.Hielo: return "HIELO";
                case GameElement.Tierra: return "TIERRA";
                case GameElement.Planta: return "PLANTA";
                case GameElement.Viento: return "VIENTO";
                case GameElement.Agua: return "AGUA";
                default: return "NINGUNO";
            }
        }
    }
}
