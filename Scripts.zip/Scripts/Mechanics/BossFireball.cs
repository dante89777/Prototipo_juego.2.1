using Platformer.Core;
using Platformer.Model;
using Platformer.View;
using UnityEngine;

namespace Platformer.Mechanics
{
    public class BossFireball : MonoBehaviour
    {
        Vector2 direction;
        float speed;
        float range;
        float hitRadius;
        int damage;
        float travelled;
        GameObject impactVfx;
        PlayerController player;

        public static BossFireball Spawn(Vector2 origin, Vector2 direction, float speed, float range,
            float hitRadius, int damage, Sprite sprite, Color color, GameObject impactVfx)
        {
            GameObject go = new GameObject("BossFireball");
            go.transform.position = new Vector3(origin.x, origin.y, 0f);
            SpriteRenderer renderer = go.AddComponent<SpriteRenderer>();
            renderer.sprite = sprite;
            renderer.color = color;
            renderer.sortingOrder = 20;
            BossFireball fireball = go.AddComponent<BossFireball>();
            fireball.direction = direction.normalized;
            fireball.speed = speed;
            fireball.range = range;
            fireball.hitRadius = hitRadius;
            fireball.damage = damage;
            fireball.impactVfx = impactVfx;
            return fireball;
        }

        void Awake()
        {
            PlatformerModel model = Simulation.GetModel<PlatformerModel>();
            player = model != null ? model.player : null;
        }

        void Update()
        {
            float step = speed * Time.deltaTime;
            transform.position += (Vector3)(direction * step);
            travelled += step;

            if (player != null && player.Health != null && player.Health.IsAlive &&
                Vector2.Distance(transform.position, player.transform.position) <= hitRadius)
            {
                player.Health.Decrement();
                Impact();
                return;
            }

            if (travelled >= range) Destroy(gameObject);
        }

        void Impact()
        {
            if (impactVfx != null) Instantiate(impactVfx, transform.position, Quaternion.identity);
            else CircleEffect.Spawn(transform.position, 0.8f, new Color(1f, 0.4f, 0.1f));
            Destroy(gameObject);
        }
    }
}
