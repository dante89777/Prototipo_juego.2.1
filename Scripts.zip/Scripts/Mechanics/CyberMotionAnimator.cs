using UnityEngine;

namespace Platformer.Mechanics
{
    [RequireComponent(typeof(CharacterSwitcher))]
    public class CyberMotionAnimator : MonoBehaviour
    {
        [SerializeField] private CharacterSwitcher switcher;
        [SerializeField] private SpriteRenderer rootRenderer;
        [SerializeField] private SpriteRenderer cyberRenderer;
        [SerializeField] private float moveSpeed = 4f;
        [SerializeField] private float bobFrequency = 8f;
        [SerializeField] private float bobAmount = 0.12f;
        [SerializeField] private float squashAmount = 0.08f;
        [SerializeField] private float tiltDegrees = 8f;

        KinematicObject kinematic;
        Vector3 basePosition;
        Vector3 baseScale;
        readonly SpriteRenderer[] ghosts = new SpriteRenderer[2];
        readonly Vector3[] ghostPositions = new Vector3[2];
        readonly Quaternion[] ghostRotations = new Quaternion[2];
        readonly Vector3[] ghostScales = new Vector3[2];

        void Awake()
        {
            bobFrequency = Mathf.Max(bobFrequency, 6f);
            bobAmount = Mathf.Max(bobAmount, 0.08f);
            squashAmount = Mathf.Max(squashAmount, 0.05f);
            tiltDegrees = Mathf.Max(tiltDegrees, 5f);

            if (switcher == null) switcher = GetComponent<CharacterSwitcher>();
            if (rootRenderer == null) rootRenderer = GetComponent<SpriteRenderer>();
            kinematic = GetComponent<KinematicObject>();
            if (cyberRenderer != null)
            {
                basePosition = cyberRenderer.transform.localPosition;
                baseScale = cyberRenderer.transform.localScale;
                for (int i = 0; i < ghosts.Length; i++)
                {
                    GameObject ghost = new GameObject("CyberGhost" + i);
                    ghost.transform.SetParent(transform, false);
                    ghosts[i] = ghost.AddComponent<SpriteRenderer>();
                    ghosts[i].sprite = cyberRenderer.sprite;
                    ghosts[i].sortingOrder = cyberRenderer.sortingOrder - 1;
                    ghosts[i].enabled = false;
                    ghostRotations[i] = Quaternion.identity;
                }
            }
        }

        void LateUpdate()
        {
            if (switcher == null || cyberRenderer == null) return;

            if (switcher.CurrentIndex != 1)
            {
                cyberRenderer.transform.localPosition = basePosition;
                cyberRenderer.transform.localRotation = Quaternion.identity;
                cyberRenderer.transform.localScale = baseScale;
                foreach (SpriteRenderer ghost in ghosts)
                    if (ghost != null) ghost.enabled = false;
                return;
            }

            if (rootRenderer != null) cyberRenderer.flipX = rootRenderer.flipX;

            Vector2 motion = kinematic != null ? kinematic.velocity : Vector2.zero;
            float move = Mathf.Clamp01(Mathf.Abs(motion.x) / Mathf.Max(0.01f, moveSpeed));
            bool airborne = kinematic != null && !kinematic.IsGrounded;
            float phase = Time.time * bobFrequency;
            float wave = Mathf.Sin(phase);
            float idle = Mathf.Sin(Time.time * 2.5f) * 0.025f * (1f - move);
            float squash = Mathf.Sin(phase * 2f) * squashAmount * move;
            float stride = Mathf.Sin(phase) * 0.28f * move;
            float jumpStretch = airborne ? Mathf.Clamp(motion.y / 10f, -0.28f, 0.30f) : 0f;

            cyberRenderer.transform.localPosition = basePosition + new Vector3(stride, Mathf.Abs(wave) * bobAmount * move + idle, 0f);
            cyberRenderer.transform.localScale = new Vector3(
                baseScale.x * (1f - squash - jumpStretch * 0.35f),
                baseScale.y * (1f + squash + jumpStretch),
                baseScale.z);

            float direction = rootRenderer != null && rootRenderer.flipX ? -1f : 1f;
            float airTilt = airborne ? Mathf.Clamp(motion.y * 1.5f, -14f, 14f) : 0f;
            Quaternion rotation = Quaternion.Euler(0f, 0f, -direction * (tiltDegrees * move + airTilt));
            cyberRenderer.transform.localRotation = rotation;

            if (move > 0.15f)
            {
                for (int i = ghosts.Length - 1; i > 0; i--)
                {
                    ghostPositions[i] = ghostPositions[i - 1];
                    ghostRotations[i] = ghostRotations[i - 1];
                    ghostScales[i] = ghostScales[i - 1];
                }
                ghostPositions[0] = cyberRenderer.transform.localPosition - new Vector3(direction * 0.22f * move, 0f, 0f);
                ghostRotations[0] = rotation;
                ghostScales[0] = cyberRenderer.transform.localScale * 0.94f;

                for (int i = 0; i < ghosts.Length; i++)
                {
                    if (ghosts[i] == null) continue;
                    ghosts[i].sprite = cyberRenderer.sprite;
                    ghosts[i].flipX = cyberRenderer.flipX;
                    ghosts[i].color = new Color(0.45f, 1f, 1f, 0.26f - i * 0.09f);
                    ghosts[i].transform.localPosition = ghostPositions[i];
                    ghosts[i].transform.localRotation = ghostRotations[i];
                    ghosts[i].transform.localScale = ghostScales[i];
                    ghosts[i].enabled = true;
                }
            }
            else
            {
                foreach (SpriteRenderer ghost in ghosts)
                    if (ghost != null) ghost.enabled = false;
            }
        }
    }
}
