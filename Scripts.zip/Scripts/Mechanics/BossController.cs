using Platformer.Core;
using Platformer.Model;
using UnityEngine;

namespace Platformer.Mechanics
{
    [RequireComponent(typeof(Health), typeof(Animator), typeof(Collider2D))]
    public class BossController : MonoBehaviour
    {
        [SerializeField] private string bossName = "MARTIAL HERO";
        [SerializeField] private float aggroRadius = 9f;
        [SerializeField] private bool autoStart = true;
        [SerializeField] private AudioClip bossTheme;
        [SerializeField] private AudioSource musicSource;
        [SerializeField] private AudioSource sfxSource;
        [SerializeField] private float deathDuration = 0.9f;

        PlatformerModel model;
        Health health;
        AudioClip victoryClip;
        bool combatStarted;
        bool victoryPlayed;
        bool deathAnimStarted;
        float deathStartTime;

        public bool AutoStart
        {
            get => autoStart;
            set => autoStart = value;
        }

        public bool CombatStarted => combatStarted;

        void Awake()
        {
            model = Simulation.GetModel<PlatformerModel>();
            health = GetComponent<Health>();

            if (musicSource == null) musicSource = gameObject.AddComponent<AudioSource>();
            musicSource.playOnAwake = false;
            musicSource.loop = true;
            musicSource.spatialBlend = 0f;
            musicSource.volume = 0.65f;
            if (bossTheme != null) musicSource.clip = bossTheme;

            if (sfxSource == null)
            {
                GameObject sfx = new GameObject("Boss Victory Audio");
                sfx.transform.SetParent(transform, false);
                sfxSource = sfx.AddComponent<AudioSource>();
            }
            sfxSource.playOnAwake = false;
            sfxSource.loop = false;
            sfxSource.spatialBlend = 0f;
            sfxSource.volume = 0.8f;

            victoryClip = CreateVictoryClip();
        }

        void Update()
        {
            if (health == null || !health.IsAlive)
            {
                if (!deathAnimStarted) StartDeathAnimation();
                if (combatStarted && Time.time >= deathStartTime + deathDuration) Victory();
                return;
            }

            if (combatStarted || !autoStart || model == null || model.player == null) return;
            if (Vector2.Distance(transform.position, model.player.transform.position) <= aggroRadius)
                StartCombat();
        }

        public void PrepareCinematic()
        {
            autoStart = false;
        }

        public void StartCombat()
        {
            combatStarted = true;
            foreach (AudioSource source in Object.FindObjectsByType<AudioSource>(FindObjectsInactive.Exclude))
            {
                if (source == musicSource || source == sfxSource || !source.isPlaying) continue;
                if (source.loop || (source.clip != null && source.clip.name == "Music")) source.Stop();
            }
            if (bossTheme != null && musicSource != null)
            {
                musicSource.clip = bossTheme;
                musicSource.Play();
            }
            if (model != null) model.ShowMessage("JEFE: " + bossName + " - COMBATE", 3f);
        }

        void StartDeathAnimation()
        {
            deathAnimStarted = true;
            deathStartTime = Time.time;

            Animator animator = GetComponent<Animator>();
            if (animator != null) animator.SetTrigger("death");

            BossPatrolMover mover = GetComponent<BossPatrolMover>();
            if (mover != null) mover.enabled = false;
            BossFireAttack fire = GetComponent<BossFireAttack>();
            if (fire != null) fire.enabled = false;
            EnemyController enemy = GetComponent<EnemyController>();
            if (enemy != null) enemy.enabled = false;
            AnimationController control = GetComponent<AnimationController>();
            if (control != null) control.enabled = false;
            Collider2D collider = GetComponent<Collider2D>();
            if (collider != null) collider.enabled = false;
        }

        void Victory()
        {
            if (victoryPlayed) return;
            victoryPlayed = true;

            if (musicSource != null) musicSource.Stop();
            if (sfxSource != null && victoryClip != null) sfxSource.PlayOneShot(victoryClip);
            if (model != null) model.ShowMessage("VICTORIA - " + bossName + " DERROTADO", 4f);
        }

        void OnDestroy()
        {
            if (musicSource != null) musicSource.Stop();
        }

        static AudioClip CreateVictoryClip()
        {
            int sampleRate = 44100;
            float duration = 1.6f;
            int length = Mathf.RoundToInt(sampleRate * duration);
            float[] samples = new float[length];
            float[] notes = { 523.25f, 659.25f, 783.99f, 1046.5f };
            float noteDuration = 0.28f;

            for (int i = 0; i < length; i++)
            {
                float t = i / (float)sampleRate;
                int noteIndex = Mathf.Min(notes.Length - 1, Mathf.FloorToInt(t / noteDuration));
                float local = t - noteIndex * noteDuration;
                float envelope = Mathf.Clamp01(1f - local / noteDuration);
                samples[i] = Mathf.Sin(2f * Mathf.PI * notes[noteIndex] * local) * envelope * 0.28f;
            }

            AudioClip clip = AudioClip.Create("VictoryFanfare", length, 1, sampleRate, false);
            clip.SetData(samples, 0);
            return clip;
        }
    }
}
