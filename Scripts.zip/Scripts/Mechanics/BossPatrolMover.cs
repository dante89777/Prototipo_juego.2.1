using Platformer.Core;
using Platformer.Model;
using UnityEngine;

namespace Platformer.Mechanics
{
    public class BossPatrolMover : MonoBehaviour
    {
        [SerializeField] private float patrolRadius = 1.5f;
        [SerializeField] private float speed = 1.5f;
        [SerializeField] private float chaseSpeed = 2.6f;
        [SerializeField] private float stopDistance = 1.6f;
        [SerializeField] private float chaseRadius = 18f;

        Rigidbody2D body;
        BossController boss;
        PlatformerModel model;
        Vector3 origin;
        float progress = 0.5f;

        void Start()
        {
            origin = transform.position;
            body = GetComponent<Rigidbody2D>();
            boss = GetComponent<BossController>();
            model = Simulation.GetModel<PlatformerModel>();
        }

        void LateUpdate()
        {
            if (TryChase(out Vector3 target))
            {
                MoveTo(target, chaseSpeed);
                Face(target);
                return;
            }

            float offset = Mathf.Lerp(-patrolRadius, patrolRadius, Mathf.PingPong(progress, 1f));
            progress += Time.deltaTime * speed / Mathf.Max(0.01f, patrolRadius * 2f);
            Vector3 patrolTarget = origin + Vector3.right * offset;
            MoveTo(patrolTarget, Mathf.Max(speed, chaseSpeed * 0.8f));
        }

        bool TryChase(out Vector3 target)
        {
            target = transform.position;
            if (boss == null || !boss.CombatStarted || model == null || model.player == null) return false;
            if (model.player.Health == null || !model.player.Health.IsAlive) return false;

            target = model.player.transform.position;
            float distance = Vector2.Distance(transform.position, target);
            return distance <= chaseRadius && distance > stopDistance;
        }

        void MoveTo(Vector3 target, float moveSpeed)
        {
            Vector2 next = Vector2.MoveTowards(transform.position, target, moveSpeed * Time.deltaTime);
            if (body != null) body.position = next;
            else transform.position = new Vector3(next.x, next.y, origin.z);
        }

        void Face(Vector3 target)
        {
            float dx = target.x - transform.position.x;
            if (Mathf.Abs(dx) < 0.05f) return;
            SpriteRenderer spriteRenderer = GetComponent<SpriteRenderer>();
            if (spriteRenderer != null) spriteRenderer.flipX = dx < 0f;
        }
    }
}
