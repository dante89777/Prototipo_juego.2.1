﻿using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace Platformer.UI
{
    /// <summary>
    /// A simple controller for switching between UI panels.
    /// </summary>
    public class MainUIController : MonoBehaviour
    {
        [Tooltip("Paneles de la interfaz. El primero es el que se muestra al iniciar.")]
        [SerializeField] private GameObject[] panels;

        GameObject mainMenuOverlay;

        public void SetActivePanel(int index)
        {
            for (var i = 0; i < panels.Length; i++)
            {
                var active = i == index;
                var g = panels[i];
                if (g.activeSelf != active) g.SetActive(active);
            }
            if (mainMenuOverlay != null && mainMenuOverlay.activeSelf != (index == 0))
                mainMenuOverlay.SetActive(index == 0);
        }

        void OnEnable()
        {
            BuildMainMenuOverlay();
            EnsureExitButtons();
            SetActivePanel(0);
        }

        void EnsureExitButtons()
        {
            for (int i = 1; i < panels.Length; i++)
            {
                GameObject panel = panels[i];
                if (panel == null || panel.transform.Find("Salir") != null) continue;
                CreateExitButton(panel.transform);
            }
        }

        void CreateExitButton(Transform parent)
        {
            GameObject buttonObject = new GameObject("Salir", typeof(RectTransform), typeof(CanvasRenderer), typeof(Image), typeof(Button));
            buttonObject.transform.SetParent(parent, false);
            RectTransform rect = buttonObject.GetComponent<RectTransform>();
            rect.anchorMin = Vector2.zero;
            rect.anchorMax = Vector2.zero;
            rect.pivot = Vector2.zero;
            rect.anchoredPosition = new Vector2(35f, 35f);
            rect.sizeDelta = new Vector2(180f, 52f);

            Image image = buttonObject.GetComponent<Image>();
            image.color = new Color(0.12f, 0.16f, 0.25f, 0.95f);

            Button button = buttonObject.GetComponent<Button>();
            ColorBlock colors = button.colors;
            colors.normalColor = Color.white;
            colors.highlightedColor = new Color(1f, 0.85f, 0.35f);
            colors.pressedColor = new Color(1f, 0.6f, 0.2f);
            button.colors = colors;
            button.onClick.AddListener(ReturnToMain);

            GameObject textObject = new GameObject("Texto", typeof(RectTransform), typeof(CanvasRenderer), typeof(TextMeshProUGUI));
            textObject.transform.SetParent(buttonObject.transform, false);
            RectTransform textRect = textObject.GetComponent<RectTransform>();
            textRect.anchorMin = new Vector2(0.5f, 0.5f);
            textRect.anchorMax = new Vector2(0.5f, 0.5f);
            textRect.anchoredPosition = Vector2.zero;
            textRect.sizeDelta = rect.sizeDelta;

            TextMeshProUGUI label = textObject.GetComponent<TextMeshProUGUI>();
            label.text = "SALIR";
            label.fontSize = 24;
            label.alignment = TextAlignmentOptions.Center;
            label.color = Color.white;
            label.raycastTarget = false;
            label.font = Resources.Load<TMP_FontAsset>("Fonts & Materials/LiberationSans SDF");
            if (label.font == null) label.font = TMP_Settings.defaultFontAsset;
        }

        void ReturnToMain()
        {
            SetActivePanel(0);
        }

        void BuildMainMenuOverlay()
        {
            if (panels == null || panels.Length == 0 || panels[0] == null) return;

            Transform root = panels[0].transform.parent;
            if (root == null || root.Find("interfaz_principal") != null) return;

            Canvas.ForceUpdateCanvases();

            Transform mainPanel = panels[0].transform;
            for (int i = 0; i < mainPanel.childCount; i++)
                mainPanel.GetChild(i).gameObject.SetActive(false);

            RectTransform rootRect = root.GetComponent<RectTransform>();
            float canvasHeight = rootRect != null && rootRect.rect.height > 0f ? rootRect.rect.height : Screen.height;
            float panelHeight = canvasHeight * 710f / 1169f;
            float panelWidth = panelHeight * 640f / 710f;
            float scale = panelHeight / 710f;
            Vector2 halfAnchor = new Vector2(0.5f, 0.5f);
            float buttonOffsetX = 5f * scale;
            Vector2 buttonSize = new Vector2(290f * scale, 60f * scale);

            Image screen = CreateImage("interfaz_principal", root, new Color(0.02f, 0.03f, 0.06f, 0.92f),
                Vector2.zero, Vector2.one, Vector2.zero, Vector2.zero, true);
            screen.transform.SetAsLastSibling();
            mainMenuOverlay = screen.gameObject;

            CreateImage("Borde", screen.transform, new Color(0.35f, 0.78f, 1f, 1f),
                halfAnchor, halfAnchor, Vector2.zero, new Vector2(panelWidth + 6f, panelHeight + 6f));
            CreateImage("Panel", screen.transform, new Color(0.045f, 0.07f, 0.12f, 0.98f),
                halfAnchor, halfAnchor, Vector2.zero, new Vector2(panelWidth, panelHeight));

            CreateMenuButton(screen.transform, "Empezar partida", "empezar partida",
                new Vector2(buttonOffsetX, 145f * scale), buttonSize, StartGame);
            CreateMenuButton(screen.transform, "Opciones", "opciones",
                new Vector2(buttonOffsetX, -15f * scale), buttonSize, OpenOptions);
            CreateMenuButton(screen.transform, "Salir del juego", "salir del juego",
                new Vector2(buttonOffsetX, -165f * scale), buttonSize, QuitGame);
        }

        void CreateMenuButton(Transform parent, string name, string label, Vector2 anchoredPosition, Vector2 sizeDelta,
            UnityEngine.Events.UnityAction action)
        {
            GameObject buttonObject = new GameObject(name, typeof(RectTransform), typeof(CanvasRenderer), typeof(Image), typeof(Button));
            buttonObject.transform.SetParent(parent, false);
            RectTransform rect = buttonObject.GetComponent<RectTransform>();
            rect.anchorMin = new Vector2(0.5f, 0.5f);
            rect.anchorMax = new Vector2(0.5f, 0.5f);
            rect.anchoredPosition = anchoredPosition;
            rect.sizeDelta = sizeDelta;
            rect.pivot = new Vector2(0.5f, 0.5f);

            Image image = buttonObject.GetComponent<Image>();
            image.sprite = RoundedSprite();
            image.color = new Color(0.12f, 0.22f, 0.36f, 1f);
            image.raycastTarget = true;

            Button button = buttonObject.GetComponent<Button>();
            ColorBlock colors = button.colors;
            colors.normalColor = Color.white;
            colors.highlightedColor = new Color(1f, 0.85f, 0.35f);
            colors.pressedColor = new Color(1f, 0.6f, 0.2f);
            button.colors = colors;
            button.onClick.AddListener(action);

            CreateText("Texto", buttonObject.transform, label, 36f, TextAlignmentOptions.Center,
                Vector2.zero, Vector2.one, Vector2.zero, Vector2.zero);
        }

        Image CreateImage(string name, Transform parent, Color color, Vector2 anchorMin, Vector2 anchorMax,
            Vector2 anchoredPosition, Vector2 sizeDelta, bool raycastTarget = false)
        {
            GameObject imageObject = new GameObject(name, typeof(RectTransform), typeof(CanvasRenderer), typeof(Image));
            imageObject.transform.SetParent(parent, false);
            RectTransform rect = imageObject.GetComponent<RectTransform>();
            rect.anchorMin = anchorMin;
            rect.anchorMax = anchorMax;
            rect.anchoredPosition = anchoredPosition;
            rect.sizeDelta = sizeDelta;
            rect.pivot = new Vector2((anchorMin.x + anchorMax.x) * 0.5f, (anchorMin.y + anchorMax.y) * 0.5f);

            Image image = imageObject.GetComponent<Image>();
            image.color = color;
            image.raycastTarget = raycastTarget;
            return image;
        }

        TextMeshProUGUI CreateText(string name, Transform parent, string value, float fontSize,
            TextAlignmentOptions alignment, Vector2 anchorMin, Vector2 anchorMax, Vector2 anchoredPosition, Vector2 sizeDelta)
        {
            GameObject textObject = new GameObject(name, typeof(RectTransform), typeof(CanvasRenderer), typeof(TextMeshProUGUI));
            textObject.transform.SetParent(parent, false);
            RectTransform rect = textObject.GetComponent<RectTransform>();
            rect.anchorMin = anchorMin;
            rect.anchorMax = anchorMax;
            rect.anchoredPosition = anchoredPosition;
            rect.sizeDelta = sizeDelta;
            rect.pivot = new Vector2((anchorMin.x + anchorMax.x) * 0.5f, (anchorMin.y + anchorMax.y) * 0.5f);

            TextMeshProUGUI text = textObject.GetComponent<TextMeshProUGUI>();
            text.font = Resources.Load<TMP_FontAsset>("Fonts & Materials/LiberationSans SDF");
            if (text.font == null) text.font = TMP_Settings.defaultFontAsset;
            text.text = value;
            text.fontSize = fontSize;
            text.alignment = alignment;
            text.color = Color.white;
            text.raycastTarget = false;
            return text;
        }

        static Sprite roundedSprite;
        static Sprite RoundedSprite()
        {
            if (roundedSprite != null) return roundedSprite;

            const int size = 64;
            const float radius = 12f;
            Texture2D texture = new Texture2D(size, size, TextureFormat.RGBA32, false);
            Color32[] pixels = new Color32[size * size];
            for (int y = 0; y < size; y++)
            {
                for (int x = 0; x < size; x++)
                {
                    float dx = Mathf.Max(radius - x, x - (size - 1 - radius), 0f);
                    float dy = Mathf.Max(radius - y, y - (size - 1 - radius), 0f);
                    float alpha = Mathf.Clamp01(radius - Mathf.Sqrt(dx * dx + dy * dy) + 0.5f);
                    pixels[y * size + x] = new Color32(255, 255, 255, (byte)(alpha * 255f));
                }
            }
            texture.SetPixels32(pixels);
            texture.Apply();
            roundedSprite = Sprite.Create(texture, new Rect(0f, 0f, size, size), new Vector2(0.5f, 0.5f), 100f);
            return roundedSprite;
        }

        void StartGame()
        {
            GameMenuController menu = GetComponent<GameMenuController>();
            if (menu != null)
            {
                menu.Resume();
                return;
            }

            MetaGameController meta = FindAnyObjectByType<MetaGameController>();
            if (meta != null) meta.Resume();
            else Time.timeScale = 1f;
        }

        void OpenOptions()
        {
            SetActivePanel(2);
        }

        void QuitGame()
        {
            GameMenuController menu = GetComponent<GameMenuController>();
            if (menu != null) menu.QuitGame();
            else Application.Quit();
        }
    }
}
