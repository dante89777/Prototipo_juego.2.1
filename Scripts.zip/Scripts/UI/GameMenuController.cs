using System.Collections.Generic;
using Platformer.Core;
using Platformer.Mechanics;
using Platformer.Model;
using Platformer.View;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace Platformer.UI
{
    public class GameMenuController : MonoBehaviour
    {
        const int hookCost = 5;
        const int lifeCost = 5;
        const int elementCost = 20;

        [SerializeField] private TMP_Text characterText;
        [SerializeField] private TMP_Text elementsText;
        [SerializeField] private TMP_Text coinsText;
        [SerializeField] private TMP_Text statusText;
        [SerializeField] private TMP_Text modeText;
        [SerializeField] private Slider volumeSlider;
        [SerializeField] private Slider sensitivitySlider;
        [SerializeField] private MetaGameController meta;
        [SerializeField] private CharacterSwitcher switcher;

        readonly PlatformerModel model = Simulation.GetModel<PlatformerModel>();

        float baseSpeed = 4f;
        float statusExpiry;
        bool hardMode;

        void Awake()
        {
            if (meta == null) meta = FindAnyObjectByType<MetaGameController>();
            if (switcher == null) switcher = FindAnyObjectByType<CharacterSwitcher>();
            if (model.player != null) baseSpeed = model.player.MaxSpeed;
            if (volumeSlider != null)
            {
                volumeSlider.SetValueWithoutNotify(AudioListener.volume);
                volumeSlider.onValueChanged.AddListener(SetVolume);
            }
            if (sensitivitySlider != null)
            {
                sensitivitySlider.SetValueWithoutNotify(0.5f);
                sensitivitySlider.onValueChanged.AddListener(SetSensitivity);
            }
            if (modeText != null) modeText.text = "MODO: NORMAL";
        }

        void Update()
        {
            if (characterText != null) characterText.text = $"PERSONAJE: {model.CurrentCharacterName}";
            if (elementsText != null) elementsText.text = $"E: {NameOf(EquippedElement(model.CurrentCharacterIndex, 0))} / Q: {NameOf(EquippedElement(model.CurrentCharacterIndex, 1))}";
            if (coinsText != null) coinsText.text = $"MONEDAS: {model.TokenCount}";
            if (statusText != null && Time.unscaledTime > statusExpiry) statusText.text = string.Empty;
        }

        public void Resume()
        {
            if (meta != null) meta.Resume();
            else Time.timeScale = 1f;
        }

        public void QuitGame()
        {
            Application.Quit();
#if UNITY_EDITOR
            UnityEditor.EditorApplication.isPlaying = false;
#endif
        }

        public void ReturnToMainPanel()
        {
            MainUIController mainUI = FindAnyObjectByType<MainUIController>();
            if (mainUI != null) mainUI.SetActivePanel(0);
        }

        public void SelectCharacter(int index)
        {
            if (switcher != null) switcher.SelectCharacter(index);
            ShowStatus(index == 0 ? "Caballero equipado" : "Cyber 10 equipado");
            Resume();
        }

        public void BuyHook()
        {
            if (model.GrappleUnlocked)
            {
                ShowStatus("Ya tienes el gancho");
                return;
            }
            if (!model.SpendTokens(hookCost))
            {
                ShowStatus("Te faltan monedas");
                return;
            }
            model.UnlockGrapple();
            ShowStatus("Gancho comprado");
        }

        public void BuyLife()
        {
            Health health = model.player != null ? model.player.Health : null;
            if (health == null)
            {
                ShowStatus("No hay jugador");
                return;
            }
            if (!model.SpendTokens(lifeCost))
            {
                ShowStatus("Te faltan monedas");
                return;
            }

            if (health.CurrentHP < health.MaxHP)
                health.Increment();
            else
                health.SetMaxHP(health.MaxHP + 1, refill: false);

            SpawnPurchaseVfx(Color.green);
            ShowStatus("Vida comprada");
        }

        public void BuyElement(int index)
        {
            GameElement element = ElementForIndex(index);
            if (element == GameElement.Ninguno) return;

            string name = NameOf(element);
            int characterIndex = model.CurrentCharacterIndex;
            bool alreadyOwned = model.HasElement(element);

            if (!alreadyOwned && !model.SpendTokens(elementCost))
            {
                ShowStatus("Te faltan monedas");
                return;
            }

            model.CollectElement(element);
            model.UnlockAttack(element);
            if (switcher != null) switcher.EquipElement(characterIndex, 1, element);
            model.EquipElement(characterIndex, 1, element);
            SpawnPurchaseVfx(ColorFor(element));
            ShowStatus(name + (alreadyOwned ? " equipado" : " desbloqueado"));
        }

        public void SetInventoryElement(int characterIndex, int slotIndex, GameElement element)
        {
            if (characterIndex < 0 || characterIndex >= model.CharacterCount) return;
            if (slotIndex < 0 || slotIndex > 1 || element == GameElement.Ninguno) return;
            if (!model.HasElement(element)) return;
            if (EquippedElement(characterIndex, 1 - slotIndex) == element) return;

            if (switcher != null) switcher.EquipElement(characterIndex, slotIndex, element);
            model.EquipElement(characterIndex, slotIndex, element);
            ShowStatus($"{NameOf(element)} -> {(slotIndex == 0 ? "E" : "Q")} / {CharacterName(characterIndex)}");
        }

        public void CycleInventoryElement(int characterIndex, int slotIndex, int direction)
        {
            GameElement current = EquippedElement(characterIndex, slotIndex);
            List<GameElement> owned = OwnedElements();
            if (owned.Count == 0) return;

            int index = owned.IndexOf(current);
            if (index < 0) index = 0;
            int step = direction >= 0 ? 1 : -1;

            for (int attempt = 1; attempt <= owned.Count; attempt++)
            {
                GameElement candidate = owned[(index + step * attempt + owned.Count * 4) % owned.Count];
                if (candidate != EquippedElement(characterIndex, 1 - slotIndex))
                {
                    SetInventoryElement(characterIndex, slotIndex, candidate);
                    return;
                }
            }
        }

        public GameElement EquippedElement(int characterIndex, int slotIndex)
        {
            if (switcher != null)
            {
                CharacterSlot slot = switcher.GetSlot(characterIndex);
                if (slot != null) return slotIndex == 0 ? slot.elementA : slot.elementB;
            }
            GameElement[] elements = model.ElementsForCharacter(characterIndex);
            return elements != null && elements.Length > slotIndex ? elements[slotIndex] : GameElement.Ninguno;
        }

        List<GameElement> OwnedElements()
        {
            var result = new List<GameElement>();
            for (int i = 1; i <= 7; i++)
            {
                GameElement element = (GameElement)i;
                if (model.HasElement(element)) result.Add(element);
            }
            return result;
        }

        public static string ElementName(GameElement element) => NameOf(element);

        public static string CharacterName(int index) => index == 0 ? "CABALLERO" : "CYBER 10";

        public void SetVolume(float value)
        {
            AudioListener.volume = Mathf.Clamp01(value);
        }

        public void SetSensitivity(float value)
        {
            if (model.player != null)
                model.player.MaxSpeed = baseSpeed * Mathf.Lerp(0.6f, 1.5f, Mathf.Clamp01(value));
        }

        public void ToggleMode()
        {
            hardMode = !hardMode;
            if (modeText != null) modeText.text = hardMode ? "MODO: DESAFÍO" : "MODO: NORMAL";
        }

        public void ShowStatus(string text)
        {
            if (statusText == null) return;
            statusText.text = text;
            statusExpiry = Time.unscaledTime + 2.5f;
        }

        static GameElement ElementForIndex(int index)
        {
            switch (index)
            {
                case 0: return GameElement.Planta;
                case 1: return GameElement.Agua;
                case 2: return GameElement.Viento;
                case 3: return GameElement.Tierra;
                default: return GameElement.Ninguno;
            }
        }

        static Color ColorFor(GameElement element)
        {
            switch (element)
            {
                case GameElement.Fuego: return new Color(1f, 0.38f, 0.12f);
                case GameElement.Rayo: return new Color(1f, 0.92f, 0.2f);
                case GameElement.Hielo: return new Color(0.45f, 0.9f, 1f);
                case GameElement.Tierra: return new Color(0.7f, 0.5f, 0.28f);
                case GameElement.Planta: return new Color(0.35f, 1f, 0.45f);
                case GameElement.Viento: return new Color(0.55f, 1f, 0.7f);
                case GameElement.Agua: return new Color(0.25f, 0.55f, 1f);
                default: return Color.white;
            }
        }

        void SpawnPurchaseVfx(Color color)
        {
            if (model.player == null) return;
            CircleEffect.Spawn(model.player.transform.position + Vector3.up * 0.6f, 1.5f, color);
        }

        static string FormatElements(GameElement[] elements)
        {
            if (elements == null || elements.Length == 0) return "-";
            var parts = new string[elements.Length];
            for (int i = 0; i < elements.Length; i++) parts[i] = NameOf(elements[i]);
            return string.Join(" / ", parts);
        }

        static string NameOf(GameElement value)
        {
            switch (value)
            {
                case GameElement.Fuego: return "FUEGO";
                case GameElement.Rayo: return "RAYO";
                case GameElement.Hielo: return "HIELO";
                case GameElement.Tierra: return "TIERRA";
                case GameElement.Planta: return "PLANTA";
                case GameElement.Viento: return "VIENTO";
                case GameElement.Agua: return "AGUA";
                default: return "NINGUNO";
            }
        }
    }
}
