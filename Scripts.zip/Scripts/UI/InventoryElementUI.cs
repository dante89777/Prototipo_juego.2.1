using System.Collections.Generic;
using System.Linq;
using Platformer.Model;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace Platformer.UI
{
    public class InventoryElementUI : MonoBehaviour
    {
        class Row
        {
            public int characterIndex;
            public int slotIndex;
            public TextMeshProUGUI label;
        }

        GameMenuController menu;
        GameObject panel;
        readonly List<Row> rows = new List<Row>();

        void Awake()
        {
            menu = GetComponent<GameMenuController>();
            if (menu == null) menu = Resources.FindObjectsOfTypeAll<GameMenuController>().FirstOrDefault();
            panel = Resources.FindObjectsOfTypeAll<GameObject>()
                .FirstOrDefault(go => go.name == "Inventario" && go.transform.Find("SelectKnight") != null);
            if (menu == null || panel == null) return;
            Build();
        }

        void Update()
        {
            if (panel == null || !panel.activeSelf) return;
            Refresh();
        }

        void Build()
        {
            if (panel.transform.Find("ElementSlots") != null) return;

            GameObject container = new GameObject("ElementSlots", typeof(RectTransform));
            container.transform.SetParent(panel.transform, false);
            RectTransform containerRect = container.GetComponent<RectTransform>();
            containerRect.anchorMin = new Vector2(0.5f, 0.5f);
            containerRect.anchorMax = new Vector2(0.5f, 0.5f);
            containerRect.anchoredPosition = new Vector2(0f, -215f);
            containerRect.sizeDelta = new Vector2(900f, 240f);

            CreateText(container.transform, "Titulo", "CAMBIAR ELEMENTO - USA < >   (E = ATAQUE / Q = DEFINITIVO)",
                new Vector2(0f, 100f), new Vector2(900f, 36f), 18, TextAlignmentOptions.Center, Color.white);

            for (int character = 0; character < 2; character++)
            {
                for (int slot = 0; slot < 2; slot++)
                {
                    int characterIndex = character;
                    int slotIndex = slot;
                    float y = 55f - (character * 2 + slot) * 42f;

                    TextMeshProUGUI label = CreateText(container.transform,
                        $"Slot_{character}_{slot}", string.Empty,
                        new Vector2(-150f, y), new Vector2(560f, 34f), 17,
                        TextAlignmentOptions.MidlineLeft, new Color(1f, 0.92f, 0.55f));

                    CreateButton(container.transform, "Menos", "<", new Vector2(220f, y), -1, characterIndex, slotIndex);
                    CreateButton(container.transform, "Mas", ">", new Vector2(310f, y), 1, characterIndex, slotIndex);

                    rows.Add(new Row { characterIndex = characterIndex, slotIndex = slotIndex, label = label });
                }
            }

            CreateExitButton();
            Refresh();
        }

        void CreateButton(Transform parent, string name, string text, Vector2 position, int direction, int characterIndex, int slotIndex)
        {
            GameObject buttonObject = new GameObject(name, typeof(RectTransform), typeof(CanvasRenderer), typeof(Image), typeof(Button));
            buttonObject.transform.SetParent(parent, false);
            RectTransform rect = buttonObject.GetComponent<RectTransform>();
            rect.anchorMin = new Vector2(0.5f, 0.5f);
            rect.anchorMax = new Vector2(0.5f, 0.5f);
            rect.anchoredPosition = position;
            rect.sizeDelta = new Vector2(60f, 34f);

            Image image = buttonObject.GetComponent<Image>();
            image.color = new Color(0.12f, 0.16f, 0.25f, 0.95f);

            Button button = buttonObject.GetComponent<Button>();
            ColorBlock colors = button.colors;
            colors.normalColor = Color.white;
            colors.highlightedColor = new Color(1f, 0.85f, 0.35f);
            colors.pressedColor = new Color(1f, 0.6f, 0.2f);
            button.colors = colors;
            button.onClick.AddListener(() => menu.CycleInventoryElement(characterIndex, slotIndex, direction));

            CreateText(buttonObject.transform, "Texto", text, Vector2.zero, rect.sizeDelta, 20,
                TextAlignmentOptions.Center, Color.white);
        }

        void CreateExitButton()
        {
            GameObject buttonObject = new GameObject("Salir", typeof(RectTransform), typeof(CanvasRenderer), typeof(Image), typeof(Button));
            buttonObject.transform.SetParent(panel.transform, false);
            RectTransform rect = buttonObject.GetComponent<RectTransform>();
            rect.anchorMin = new Vector2(0f, 0f);
            rect.anchorMax = new Vector2(0f, 0f);
            rect.pivot = new Vector2(0f, 0f);
            rect.anchoredPosition = new Vector2(35f, 35f);
            rect.sizeDelta = new Vector2(180f, 52f);

            Image image = buttonObject.GetComponent<Image>();
            image.color = new Color(0.12f, 0.16f, 0.25f, 0.95f);

            Button button = buttonObject.GetComponent<Button>();
            ColorBlock colors = button.colors;
            colors.normalColor = Color.white;
            colors.highlightedColor = new Color(1f, 0.85f, 0.35f);
            colors.pressedColor = new Color(1f, 0.6f, 0.2f);
            button.colors = colors;
            button.onClick.AddListener(menu.ReturnToMainPanel);

            CreateText(buttonObject.transform, "Texto", "SALIR", Vector2.zero, rect.sizeDelta, 24,
                TextAlignmentOptions.Center, Color.white);
        }

        TextMeshProUGUI CreateText(Transform parent, string name, string text, Vector2 position, Vector2 size,
            float fontSize, TextAlignmentOptions alignment, Color color)
        {
            GameObject textObject = new GameObject(name, typeof(RectTransform), typeof(CanvasRenderer), typeof(TextMeshProUGUI));
            textObject.transform.SetParent(parent, false);
            RectTransform rect = textObject.GetComponent<RectTransform>();
            rect.anchorMin = new Vector2(0.5f, 0.5f);
            rect.anchorMax = new Vector2(0.5f, 0.5f);
            rect.anchoredPosition = position;
            rect.sizeDelta = size;

            TextMeshProUGUI label = textObject.GetComponent<TextMeshProUGUI>();
            label.text = text;
            label.fontSize = fontSize;
            label.alignment = alignment;
            label.color = color;
            label.raycastTarget = false;
            label.font = Resources.Load<TMP_FontAsset>("Fonts & Materials/LiberationSans SDF");
            if (label.font == null) label.font = TMP_Settings.defaultFontAsset;
            return label;
        }

        void Refresh()
        {
            foreach (Row row in rows)
            {
                string key = row.slotIndex == 0 ? "E" : "Q";
                GameElement element = menu.EquippedElement(row.characterIndex, row.slotIndex);
                row.label.text = $"{GameMenuController.CharacterName(row.characterIndex)}  {key}: {GameMenuController.ElementName(element)}";
            }
        }
    }
}
