using System.Collections;
using Platformer.Core;
using Platformer.Mechanics;
using Platformer.Model;
using Platformer.View;
using TMPro;
using Unity.Cinemachine;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.UI;

namespace Platformer.UI
{
    public class GameCinematicController : MonoBehaviour
    {
        [SerializeField] private GameObject boss;
        [SerializeField] private Sprite cyberPortrait;
        [SerializeField] private TMP_FontAsset dialogueFont;
        [SerializeField] private float bossTriggerRadius = 12f;
        [SerializeField] private float zoomSize = 2.1f;
        [SerializeField] private float zoomDuration = 0.9f;
        [SerializeField] private float holdDuration = 0.7f;
        [SerializeField] private string introLine = "Que esta pasando en el cruze, acaso atravezamos una grieta";
        [SerializeField] private string bossLine = "Estoy en el reino de los monstruos y ustedes no son mas que una ilucion";

        const float ClickTimeout = 20f;

        readonly PlatformerModel model = Simulation.GetModel<PlatformerModel>();

        Canvas canvas;
        TMP_FontAsset font;
        Image portraitImage;
        TMP_Text speakerText;
        TMP_Text dialogueText;
        TMP_Text hintText;
        BossController bossController;
        bool introDone;
        bool bossFlowStarted;
        bool collisionsIgnored;
        bool originalCollisionIgnored;

        void Awake()
        {
            if (boss == null) boss = GameObject.Find("MartialHeroBoss");
            if (boss != null) bossController = boss.GetComponent<BossController>();
            if (cyberPortrait == null)
            {
                CharacterSwitcher switcher = FindAnyObjectByType<CharacterSwitcher>();
                CharacterSlot slot = switcher != null ? switcher.GetSlot(1) : null;
                if (slot != null) cyberPortrait = slot.portrait;
            }
            BuildUi();
        }

        IEnumerator Start()
        {
            MetaGameController meta = FindAnyObjectByType<MetaGameController>();
            while (Time.timeScale <= 0f || (meta != null && meta.MainMenuVisible)) yield return null;
            yield return IntroFlow();
        }

        void Update()
        {
            if (bossFlowStarted && bossController != null && bossController.CombatStarted && model != null && model.player != null &&
                !model.player.ControlEnabled && model.player.Health != null && model.player.Health.IsAlive)
                SetPlayerControl(true);

            if (!introDone || bossFlowStarted || boss == null || bossController == null || bossController.CombatStarted) return;
            if (model == null || model.player == null) return;

            Health health = boss.GetComponent<Health>();
            if (health == null || !health.IsAlive) return;

            if (Vector2.Distance(model.player.transform.position, boss.transform.position) <= bossTriggerRadius)
            {
                bossFlowStarted = true;
                StartCoroutine(BossFlow());
            }
        }

        IEnumerator IntroFlow()
        {
            if (bossController != null) bossController.PrepareCinematic();
            while (model == null || model.player == null) yield return null;

            SetPlayerControl(false);
            SetCinematicCollisions(true);
            try
            {
                ShowDialogue(cyberPortrait, "CYBER 10", introLine);
                yield return WaitForClick();
            }
            finally
            {
                HideDialogue();
                SetCinematicCollisions(false);
                SetPlayerControl(true);
                introDone = true;
            }
        }

        IEnumerator BossFlow()
        {
            SetPlayerControl(false);
            SetCinematicCollisions(true);

            try
            {
                if (bossController != null) bossController.PrepareCinematic();

                SpriteRenderer renderer = boss != null ? boss.GetComponent<SpriteRenderer>() : null;
                ShowDialogue(renderer != null ? renderer.sprite : null, "JEFE", bossLine);
                yield return WaitForClick();
                HideDialogue();

                yield return BossZoomAndAttack();

                if (bossController != null) bossController.StartCombat();
            }
            finally
            {
                HideDialogue();
                SetCinematicCollisions(false);
                SetPlayerControl(true);
            }
        }

        IEnumerator BossZoomAndAttack()
        {
            Camera cam = Camera.main;
            if (cam == null || boss == null) yield break;

            CinemachineBrain brain = cam.GetComponent<CinemachineBrain>();
            bool restoreBrain = brain != null && brain.enabled;

            try
            {
                if (restoreBrain) brain.enabled = false;

                Vector3 startPosition = cam.transform.position;
                float startSize = cam.orthographicSize;
                Vector3 targetPosition = new Vector3(boss.transform.position.x, boss.transform.position.y + 0.6f, startPosition.z);

                yield return MoveCamera(cam, startPosition, targetPosition, startSize, zoomSize, zoomDuration);
                yield return BossAttackAnimation();
                yield return new WaitForSecondsRealtime(holdDuration);
                yield return MoveCamera(cam, targetPosition, startPosition, zoomSize, startSize, 0.6f);
            }
            finally
            {
                if (restoreBrain && brain != null) brain.enabled = true;
            }
        }

        IEnumerator MoveCamera(Camera cam, Vector3 from, Vector3 to, float fromSize, float toSize, float duration)
        {
            float elapsed = 0f;
            while (elapsed < duration)
            {
                elapsed += Time.unscaledDeltaTime;
                float t = Mathf.SmoothStep(0f, 1f, Mathf.Clamp01(elapsed / duration));
                cam.transform.position = Vector3.Lerp(from, to, t);
                cam.orthographicSize = Mathf.Lerp(fromSize, toSize, t);
                yield return null;
            }
            cam.transform.position = to;
            cam.orthographicSize = toSize;
        }

        IEnumerator BossAttackAnimation()
        {
            if (boss == null) yield break;

            Transform bossTransform = boss.transform;
            Vector3 startPosition = bossTransform.position;
            Vector3 startScale = bossTransform.localScale;
            Quaternion startRotation = bossTransform.rotation;
            SpriteRenderer renderer = boss.GetComponent<SpriteRenderer>();
            Color startColor = renderer != null ? renderer.color : Color.white;

            try
            {
                Animator animator = boss.GetComponent<Animator>();
                SetTriggerIfExists(animator, "attack");

                for (int i = 0; i < 2; i++)
                {
                    float elapsed = 0f;
                    float direction = i % 2 == 0 ? 1f : -1f;
                    while (elapsed < 0.3f)
                    {
                        elapsed += Time.unscaledDeltaTime;
                        float phase = Mathf.Clamp01(elapsed / 0.3f);
                        float pulse = Mathf.Sin(phase * Mathf.PI);
                        bossTransform.position = startPosition + Vector3.right * (0.9f * pulse * direction);
                        bossTransform.localScale = new Vector3(
                            startScale.x * (1f + 0.12f * pulse),
                            startScale.y * (1f - 0.08f * pulse),
                            startScale.z);
                        bossTransform.rotation = Quaternion.Euler(0f, 0f, startRotation.eulerAngles.z + Mathf.Sin(phase * Mathf.PI * 2f) * 8f);
                        if (renderer != null) renderer.color = Color.Lerp(startColor, new Color(1f, 0.92f, 0.2f), pulse * 0.6f);
                        yield return null;
                    }

                    CircleEffect.Spawn(bossTransform.position + Vector3.right * (1.2f * direction), 1.6f, new Color(1f, 0.85f, 0.25f));
                    yield return new WaitForSecondsRealtime(0.15f);
                }
            }
            finally
            {
                bossTransform.position = startPosition;
                bossTransform.localScale = startScale;
                bossTransform.rotation = startRotation;
                if (renderer != null) renderer.color = startColor;
            }
        }

        IEnumerator WaitForClick()
        {
            bool pressed = false;
            float elapsed = 0f;
            while (!pressed && elapsed < ClickTimeout)
            {
                if (Mouse.current != null && Mouse.current.leftButton.wasPressedThisFrame) pressed = true;
                if (Keyboard.current != null &&
                    (Keyboard.current.enterKey.wasPressedThisFrame || Keyboard.current.spaceKey.wasPressedThisFrame))
                    pressed = true;
                if (Gamepad.current != null &&
                    (Gamepad.current.buttonSouth.wasPressedThisFrame || Gamepad.current.startButton.wasPressedThisFrame))
                    pressed = true;
                elapsed += Time.unscaledDeltaTime;
                yield return null;
            }

            elapsed = 0f;
            while (Mouse.current != null && Mouse.current.leftButton.isPressed && elapsed < 0.5f)
            {
                elapsed += Time.unscaledDeltaTime;
                yield return null;
            }
        }

        void BuildUi()
        {
            GameObject canvasObject = new GameObject("CinematicCanvas", typeof(Canvas), typeof(CanvasScaler), typeof(GraphicRaycaster));
            canvas = canvasObject.GetComponent<Canvas>();
            canvas.renderMode = RenderMode.ScreenSpaceOverlay;
            canvas.sortingOrder = 500;

            CanvasScaler scaler = canvasObject.GetComponent<CanvasScaler>();
            scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
            scaler.referenceResolution = new Vector2(1920f, 1080f);
            scaler.matchWidthOrHeight = 0.5f;

            font = dialogueFont;
            if (font == null) font = Resources.Load<TMP_FontAsset>("Fonts & Materials/LiberationSans SDF");
            if (font == null) font = TMP_Settings.defaultFontAsset;

            Image backdrop = CreateImage("Fondo", canvas.transform, new Color(0f, 0f, 0f, 0.55f),
                Vector2.zero, Vector2.one, Vector2.zero, Vector2.zero);

            CreateImage("MarcoPanel", backdrop.transform, new Color(0.35f, 0.78f, 1f, 1f),
                new Vector2(0.5f, 0f), new Vector2(0.5f, 0f), new Vector2(0f, 120f), new Vector2(1512f, 252f));

            Image panel = CreateImage("Panel", backdrop.transform, new Color(0.04f, 0.09f, 0.17f, 0.96f),
                new Vector2(0.5f, 0f), new Vector2(0.5f, 0f), new Vector2(0f, 120f), new Vector2(1500f, 240f));

            CreateImage("MarcoRetrato", panel.transform, new Color(1f, 0.78f, 0.25f, 1f),
                new Vector2(0f, 0.5f), new Vector2(0f, 0.5f), new Vector2(110f, 0f), new Vector2(196f, 196f));

            portraitImage = CreateImage("Retrato", panel.transform, Color.white,
                new Vector2(0f, 0.5f), new Vector2(0f, 0.5f), new Vector2(110f, 0f), new Vector2(180f, 180f));
            portraitImage.preserveAspect = true;

            CreateImage("PlacaNombre", panel.transform, new Color(0.08f, 0.2f, 0.36f, 0.95f),
                new Vector2(0f, 1f), new Vector2(0f, 1f), new Vector2(230f, -26f), new Vector2(520f, 52f));

            speakerText = CreateText("Nombre", panel.transform, "CYBER 10", 34f, TextAlignmentOptions.Left,
                new Vector2(0f, 1f), new Vector2(0f, 1f), new Vector2(245f, -31f), new Vector2(500f, 44f));
            speakerText.color = new Color(0.55f, 0.9f, 1f);

            dialogueText = CreateText("Dialogo", panel.transform, string.Empty, 28f, TextAlignmentOptions.TopLeft,
                new Vector2(0f, 1f), new Vector2(0f, 1f), new Vector2(230f, -92f), new Vector2(1150f, 100f));

            hintText = CreateText("Pista", panel.transform, "CLICK IZQUIERDO PARA CONTINUAR", 22f, TextAlignmentOptions.BottomRight,
                new Vector2(1f, 0f), new Vector2(1f, 0f), new Vector2(-28f, 18f), new Vector2(520f, 36f));
            hintText.color = new Color(0.75f, 0.85f, 1f);

            canvasObject.SetActive(false);
        }

        Image CreateImage(string name, Transform parent, Color color, Vector2 anchorMin, Vector2 anchorMax, Vector2 anchoredPosition, Vector2 sizeDelta)
        {
            GameObject imageObject = new GameObject(name, typeof(RectTransform), typeof(CanvasRenderer), typeof(Image));
            imageObject.transform.SetParent(parent, false);
            Image image = imageObject.GetComponent<Image>();
            image.color = color;
            image.raycastTarget = false;
            ApplyRect(image.rectTransform, anchorMin, anchorMax, anchoredPosition, sizeDelta);
            return image;
        }

        TMP_Text CreateText(string name, Transform parent, string value, float fontSize, TextAlignmentOptions alignment,
            Vector2 anchorMin, Vector2 anchorMax, Vector2 anchoredPosition, Vector2 sizeDelta)
        {
            GameObject textObject = new GameObject(name, typeof(RectTransform), typeof(CanvasRenderer), typeof(TextMeshProUGUI));
            textObject.transform.SetParent(parent, false);
            TextMeshProUGUI text = textObject.GetComponent<TextMeshProUGUI>();
            text.font = font != null ? font : TMP_Settings.defaultFontAsset;
            text.text = value;
            text.fontSize = fontSize;
            text.alignment = alignment;
            text.color = Color.white;
            text.enableWordWrapping = true;
            text.raycastTarget = false;
            ApplyRect(text.rectTransform, anchorMin, anchorMax, anchoredPosition, sizeDelta);
            return text;
        }

        static void ApplyRect(RectTransform rect, Vector2 anchorMin, Vector2 anchorMax, Vector2 anchoredPosition, Vector2 sizeDelta)
        {
            rect.anchorMin = anchorMin;
            rect.anchorMax = anchorMax;
            rect.anchoredPosition = anchoredPosition;
            rect.sizeDelta = sizeDelta;
            float pivotX = Mathf.Approximately(anchorMin.x, anchorMax.x) ? anchorMin.x : 0.5f;
            float pivotY = Mathf.Approximately(anchorMin.y, anchorMax.y) ? anchorMin.y : 0.5f;
            rect.pivot = new Vector2(pivotX, pivotY);
        }

        void ShowDialogue(Sprite portrait, string speaker, string text)
        {
            portraitImage.sprite = portrait;
            portraitImage.enabled = portrait != null;
            speakerText.text = speaker;
            dialogueText.text = text;
            canvas.gameObject.SetActive(true);
        }

        void HideDialogue()
        {
            if (canvas != null) canvas.gameObject.SetActive(false);
        }

        void OnDisable()
        {
            SetCinematicCollisions(false);
            SetPlayerControl(true);
        }

        void SetCinematicCollisions(bool ignore)
        {
            if (model == null || model.player == null || boss == null) return;

            Collider2D playerCollider = model.player.GetComponent<Collider2D>();
            Collider2D bossCollider = boss.GetComponent<Collider2D>();
            if (playerCollider == null || bossCollider == null) return;

            if (ignore)
            {
                if (collisionsIgnored) return;
                originalCollisionIgnored = Physics2D.GetIgnoreCollision(playerCollider, bossCollider);
                Physics2D.IgnoreCollision(playerCollider, bossCollider, true);
                collisionsIgnored = true;
            }
            else
            {
                if (!collisionsIgnored) return;
                Physics2D.IgnoreCollision(playerCollider, bossCollider, originalCollisionIgnored);
                collisionsIgnored = false;
            }
        }

        void SetPlayerControl(bool enabled)
        {
            if (model == null || model.player == null) return;
            if (enabled && model.player.Health != null && !model.player.Health.IsAlive) return;
            model.player.ControlEnabled = enabled;
        }

        static void SetTriggerIfExists(Animator animator, string parameter)
        {
            if (animator == null) return;
            foreach (AnimatorControllerParameter candidate in animator.parameters)
            {
                if (candidate.name == parameter && candidate.type == AnimatorControllerParameterType.Trigger)
                {
                    animator.SetTrigger(parameter);
                    return;
                }
            }
        }
    }
}
